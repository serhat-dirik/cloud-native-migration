MIGRATION_ISSUES_DETAILS["ce9cc982-262c-45b1-8e39-a3caf6bbade7"] = [
{description: "<p><code>weblogic.jndi.WLInitialContextFactory<\/code> is an implementation of <code>InitialContextFactory<\/code> used to get object instances from JNDI.<\/p><p>The equivalent functionality needs to be configured on JBoss EAP 7 using <code>org.jboss.naming.remote.client.InitialContextFactory<\/code>. Then the context could be instanticated as follows: <code>InitialContext ctx = new InitialContext();<\/code>.<\/p>", ruleID: "weblogic-eap7-016000", issueName: "WebLogic InitialContextFactory",
problemSummaryID: "ce9cc982-262c-45b1-8e39-a3caf6bbade7", files: [
{l:"<a class='' href='InventoryNotificationMDB_java.html?project=1290352'>com.redhat.coolstore.service.InventoryNotificationMDB<\/a>", oc:"2"},
], resourceLinks: [
{h:"https://access.redhat.com/solutions/396853", t:"How to configure an EJB client in JBoss EAP 6"},
{h:"https://access.redhat.com/solutions/161543", t:"Calling JMS resources and EJB in EAP 6 from Weblogic"},
]},
];
onProblemSummaryLoaded("ce9cc982-262c-45b1-8e39-a3caf6bbade7");