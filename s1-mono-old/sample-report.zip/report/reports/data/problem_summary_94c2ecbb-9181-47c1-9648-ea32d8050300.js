MIGRATION_ISSUES_DETAILS["94c2ecbb-9181-47c1-9648-ea32d8050300"] = [
{description: "<p>WebLogic <code>ApplicationLifecycleEvent<\/code> must be replaced with standard Java EE <code>ServletContextEvent<\/code>. Otherwise, a custom solution using CDI\'s <code>ApplicationScoped<\/code> beans or EJB\'s <code>@Startup<\/code> beans is required in order to propagate a custom event object because <code>ServletContextEvent<\/code> types are not extendible in the standard Java EE programming model.<\/p><p>Use a <code>javax.servlet.ServletContextListener<\/code> with <code>@javax.annotation.servlet.WebListener<\/code>, or an EJB 3.1 <code>@javax.ejb.Startup<\/code> <code>@javax.ejb.Singleton<\/code> service bean.<\/p>", ruleID: "weblogic-webapp-eap7-05000", issueName: "WebLogic ApplicationLifecycleEvent",
problemSummaryID: "94c2ecbb-9181-47c1-9648-ea32d8050300", files: [
{l:"<a class='' href='StartupListener_java.html?project=1290352'>com.redhat.coolstore.utils.StartupListener<\/a>", oc:"1"},
], resourceLinks: [
{h:"http://docs.oracle.com/cd/E13222_01/wls/docs90/programming/lifecycle.html", t:"WebLogic custom ApplicationLifecycleEvent Documentation"},
{h:"http://docs.oracle.com/javaee/7/api/javax/servlet/ServletContextEvent.html", t:"Java EE ServletContextEvent JavaDoc"},
{h:"https://access.redhat.com/articles/1326703", t:"Migrate WebLogic ApplicationLifecycleEvent to standard EJB with JBoss EAP"},
]},
];
onProblemSummaryLoaded("94c2ecbb-9181-47c1-9648-ea32d8050300");