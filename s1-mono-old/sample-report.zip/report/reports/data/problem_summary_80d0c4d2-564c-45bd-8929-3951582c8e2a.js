MIGRATION_ISSUES_DETAILS["80d0c4d2-564c-45bd-8929-3951582c8e2a"] = [
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.i18n.logging.NonCatalogLogger<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "80d0c4d2-564c-45bd-8929-3951582c8e2a", files: [
{l:"<a class='' href='OrderServiceMDB_java.html?project=1290352'>com.redhat.coolstore.service.OrderServiceMDB<\/a>", oc:"2"},
], resourceLinks: [
]},
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.application.ApplicationLifecycleEvent<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "80d0c4d2-564c-45bd-8929-3951582c8e2a", files: [
{l:"<a class='' href='StartupListener_java.html?project=1290352'>com.redhat.coolstore.utils.StartupListener<\/a>", oc:"2"},
], resourceLinks: [
]},
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.application.ApplicationLifecycleListener<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "80d0c4d2-564c-45bd-8929-3951582c8e2a", files: [
{l:"<a class='' href='StartupListener_java.html?project=1290352'>com.redhat.coolstore.utils.StartupListener<\/a>", oc:"2"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("80d0c4d2-564c-45bd-8929-3951582c8e2a");