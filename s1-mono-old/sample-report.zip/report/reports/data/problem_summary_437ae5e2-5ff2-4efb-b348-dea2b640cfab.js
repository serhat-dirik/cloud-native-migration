MIGRATION_ISSUES_DETAILS["437ae5e2-5ff2-4efb-b348-dea2b640cfab"] = [
{description: "<p>The WebLogic <code>&lt;trans-timeout-seconds&gt;<\/code> configuration element sets the maximum duration for an EJB\'s container-initiated transactions, in seconds, after which the transaction is rolled back. <\/p><p>In JBoss EAP 6+, you can achieve the same behavior by using the <code>TransactionTimeout<\/code> annotation.<\/p>", ruleID: "weblogic-xml-descriptor-19000", issueName: "WebLogic EJB XML (weblogic-ejb-jar.xml) trans-timeout-seconds",
problemSummaryID: "437ae5e2-5ff2-4efb-b348-dea2b640cfab", files: [
{l:"<a class='' href='weblogic_ejb_jar_xml.html?project=1290352'>WEB-INF/weblogic-ejb-jar.xml<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://docs.oracle.com/middleware/1221/wls/WLMDB/summary.htm#r35c1-t4", t:"WebLogic Server Deployment Elements"},
{h:"https://access.redhat.com/solutions/90553", t:"How to set EJB transaction timeout in JBoss EAP 6"},
{h:"https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/6.4/html-single/administration_and_configuration_guide/#Session_Bean_Transaction_Timeout", t:"JBoss EAP 6 - Session Bean Transaction Timeout"},
]},
];
onProblemSummaryLoaded("437ae5e2-5ff2-4efb-b348-dea2b640cfab");