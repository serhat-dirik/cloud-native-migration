MIGRATION_ISSUES_DETAILS["9a86ea50-7e1b-40d6-aa33-7553fb7bf33b"] = [
{description: "<p>The application uses JAXB<\/p>", ruleID: "javaee-technology-usage-00090", issueName: "JAXB",
problemSummaryID: "9a86ea50-7e1b-40d6-aa33-7553fb7bf33b", files: [
{l:"<a class='' href='InventoryEntity_java.html?project=1290352'>com.redhat.coolstore.model.InventoryEntity<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("9a86ea50-7e1b-40d6-aa33-7553fb7bf33b");