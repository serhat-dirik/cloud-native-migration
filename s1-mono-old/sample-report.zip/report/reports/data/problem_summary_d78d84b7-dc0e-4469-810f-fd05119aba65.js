MIGRATION_ISSUES_DETAILS["d78d84b7-dc0e-4469-810f-fd05119aba65"] = [
{description: "<p>The application uses Common Annotations<\/p>", ruleID: "javaee-technology-usage-00080", issueName: "Common Annotations",
problemSummaryID: "d78d84b7-dc0e-4469-810f-fd05119aba65", files: [
{l:"<a class='' href='DataBaseMigrationStartup_java.html?project=1290352'>com.redhat.coolstore.utils.DataBaseMigrationStartup<\/a>", oc:"1"},
{l:"<a class='' href='ShoppingCartService_java.html?project=1290352'>com.redhat.coolstore.service.ShoppingCartService<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("d78d84b7-dc0e-4469-810f-fd05119aba65");