MIGRATION_ISSUES_DETAILS["fb58460e-3033-404a-bb01-fe2ca2af33f6"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "fb58460e-3033-404a-bb01-fe2ca2af33f6", files: [
{l:"<a class='' href='web_xml.html?project=1290352'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("fb58460e-3033-404a-bb01-fe2ca2af33f6");