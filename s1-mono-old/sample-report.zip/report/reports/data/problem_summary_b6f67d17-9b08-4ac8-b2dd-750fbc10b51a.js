MIGRATION_ISSUES_DETAILS["b6f67d17-9b08-4ac8-b2dd-750fbc10b51a"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "b6f67d17-9b08-4ac8-b2dd-750fbc10b51a", files: [
{l:"<a class='' href='pom_xml.html?project=1290352'>META-INF/maven/com.redhat.coolstore/monolith/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.5.html?project=1290352'>META-INF/maven/org.flywaydb/flyway-core/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];
onProblemSummaryLoaded("b6f67d17-9b08-4ac8-b2dd-750fbc10b51a");